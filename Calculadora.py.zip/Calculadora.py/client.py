import socket

cliente = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
cliente.connect(('localhost', 12345))

while True: # Loop para interagir com o servidor.
    msg = cliente.recv(1024).decode()
    operacao = input(msg)
    cliente.send(operacao.encode())

    if operacao.lower() == 'sair':
        print("Conexao encerrada.")
        break

    msg = cliente.recv(1024).decode()
    num1 = input(msg)
    cliente.send(num1.encode())

    msg = cliente.recv(1024).decode()
    num2 = input(msg)
    cliente.send(num2.encode())

    resultado = cliente.recv(1024).decode()
    print(resultado)

cliente.close()
