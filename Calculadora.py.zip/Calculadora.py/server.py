#Fornece acesso às funções de rede para criar e gerenciar conexões.
import socket
import threading

# --- Funções de Operações Matemáticas ---
def somar(a, b):
    return a + b

def subtrair(a, b):
    return a - b

def multiplicar(a, b):
    return a * b

def dividir(a, b):
    if b == 0:
        return "Erro: divisão por zero"
    return a / b

    # Função executada em uma nova thread para cada cliente conectado.
    # Responsável por toda a comunicação e processamento das requisições do cliente.
def tratar_cliente(conexao, endereco):
    print(f"[+] Cliente conectado: {endereco}")
    while True:
        conexao.send(b"Digite a operacao (somar, subtrair, multiplicar, dividir) ou 'sair': ")
        operacao = conexao.recv(1024).decode().strip().lower()

        if operacao == 'sair':
            print(f"[-] Cliente {endereco} desconectado.")
            break

        if operacao not in ['somar', 'subtrair', 'multiplicar', 'dividir']:
            conexao.send(b"Operacao invalida.\n")
            continue

        conexao.send(b"Digite o primeiro numero: ")
        try:
            num1 = float(conexao.recv(1024).decode().strip())
        except:
            conexao.send(b"Numero invalido.\n")
            continue

        conexao.send(b"Digite o segundo numero: ")
        try:
            num2 = float(conexao.recv(1024).decode().strip())
        except:
            conexao.send(b"Numero invalido.\n")
            continue
        
        # --- Execução da Operação ---
        if operacao == 'somar':
            resultado = somar(num1, num2)
        elif operacao == 'subtrair':
            resultado = subtrair(num1, num2)
        elif operacao == 'multiplicar':
            resultado = multiplicar(num1, num2)
        elif operacao == 'dividir':
            resultado = dividir(num1, num2)

        conexao.send(f"Resultado: {resultado}\n".encode())

    conexao.close()

# Cria o socket do servidor
def iniciar_servidor():
    servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    servidor.bind(('localhost', 12345))
    servidor.listen()

    print("[*] Servidor ativo, aguardando conexoes...")

    while True:  # Loop para aceitar continuamente novas conexões de clientes.
        conexao, endereco = servidor.accept()
        thread = threading.Thread(target=tratar_cliente, args=(conexao, endereco))
        thread.start()

iniciar_servidor()
